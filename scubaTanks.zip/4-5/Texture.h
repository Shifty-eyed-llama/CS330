#pragma once
#include <string>

class _2D_Image
{
	unsigned int Tex_ID;

public:
	_2D_Image(const std::string& texture_filePath, const std::string& name /*= "m_texture"*/, unsigned int format, unsigned internalFormat);
	
	~_2D_Image()
	{}

	void unbind();
	void bind(unsigned int slot /*= 0*/);
};